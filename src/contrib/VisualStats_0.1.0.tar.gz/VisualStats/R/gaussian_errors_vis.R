#'
#'
#' Adapted from http://web.vu.lt/mif/a.buteikis/wp-content/uploads/PE_Book/3-4-UnivarMLE.html
gaussian_errors_vis <- function(df,
								...) {

}

if(FALSE) {

}
