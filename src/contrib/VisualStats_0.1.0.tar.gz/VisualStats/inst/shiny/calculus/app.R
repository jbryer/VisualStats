library(shiny)
shinyApp(ui = calculus_shiny_ui, server = calculus_shiny_server)
