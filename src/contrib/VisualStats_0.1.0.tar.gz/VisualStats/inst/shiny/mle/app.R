library(VisualStats)
shiny::shinyApp(ui = mle_shiny_ui, mle_shiny_server)
