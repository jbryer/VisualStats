library(VisualStats)
shinyApp(ui = r_squared_shiny_ui, server = r_squared_shiny_server)
