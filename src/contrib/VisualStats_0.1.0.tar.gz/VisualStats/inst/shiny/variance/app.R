library(VisualStats)
shinyApp(ui = variance_shiny_ui, server = variance_shiny_server)
