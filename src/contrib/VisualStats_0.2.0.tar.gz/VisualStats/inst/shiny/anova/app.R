library(VisualStats)
shinyApp(ui = anova_shiny_ui, server = anova_shiny_server)
