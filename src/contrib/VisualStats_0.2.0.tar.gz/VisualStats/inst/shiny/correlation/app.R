library(VisualStats)
shinyApp(ui = correlation_shiny_ui, server = correlation_shiny_server)
