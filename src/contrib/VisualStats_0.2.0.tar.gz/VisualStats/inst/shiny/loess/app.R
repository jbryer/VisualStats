library(VisualStats)
shinyApp(ui = loess_shiny_ui, server = loess_shiny_server)
